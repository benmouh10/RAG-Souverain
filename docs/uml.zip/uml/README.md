# Diagrammes UML — RAG Souverain

Sources **PlantUML** pour l'étude de conception (voir `CONCEPTION_STUDY.md`).

## Contenu

| Fichier | Diagramme |
|---|---|
| `use_case.puml` | Diagramme de cas d'utilisation (acteurs Admin / Utilisateur, RBAC) |
| `class.puml` | Diagramme de classes (ingestion, indexation, retrieval, génération, évaluation, persistance) |
| `sequence_login.puml` | Séquence — connexion et authentification RBAC |
| `sequence_chat.puml` | Séquence — pipeline question → réponse (chat RAG) |
| `sequence_indexation.puml` | Séquence — indexation d'un fichier avec versionnage |
| `sequence_evaluation.puml` | Séquence — évaluation Ragas (timeout 30 s / question) |
| `activity_chat.puml` | Activité — pipeline RAG (salutation, retrieval hybride, génération) |
| `activity_ingestion.puml` | Activité — ingestion et indexation de documents |
| `component.puml` | Composants — UI, pipeline RAG, persistance |
| `deployment.puml` | Déploiement — Docker Compose, réseau isolé, Ollama hôte, volumes |
| `state.puml` | États — session RBAC et versionnage des fichiers |

## Rendu

Les rendus **PNG** sont disponibles dans `docs/uml/png/` (prêts pour le rapport de stage).

Outil en ligne : https://www.plantuml.com/plantuml (copier le contenu d'un fichier).

En local (Java requis) :

```bash
plantuml -tsvg docs/uml/use_case.puml
plantuml -tpng docs/uml/*.puml
```

Extension VS Code : *PlantUML* (jebbs.plantuml) — aperçu en direct.
